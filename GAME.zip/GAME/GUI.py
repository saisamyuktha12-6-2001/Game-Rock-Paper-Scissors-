# GUI-based Rock-Paper-Scissors Game using Tkinter

import tkinter as tk
from tkinter import messagebox
import random

class RockPaperScissors:
    def __init__(self, root):
        self.root = root
        self.root.title("Rock-Paper-Scissors Game")
        
        self.user_score = 0
        self.computer_score = 0

        self.label = tk.Label(root, text="Choose Rock, Paper, or Scissors")
        self.label.pack(pady=10)

        self.rock_button = tk.Button(root, text="Rock", command=lambda: self.play("rock"))
        self.rock_button.pack(side="left", padx=20)

        self.paper_button = tk.Button(root, text="Paper", command=lambda: self.play("paper"))
        self.paper_button.pack(side="left", padx=20)

        self.scissors_button = tk.Button(root, text="Scissors", command=lambda: self.play("scissors"))
        self.scissors_button.pack(side="left", padx=20)

        self.result_label = tk.Label(root, text="")
        self.result_label.pack(pady=10)

        self.score_label = tk.Label(root, text="Score: You 0 - Computer 0")
        self.score_label.pack(pady=10)

    def get_computer_choice(self):
        choices = ["rock", "paper", "scissors"]
        return random.choice(choices)

    def determine_winner(self, user_choice, computer_choice):
        if user_choice == computer_choice:
            return "It's a tie!"
        elif (user_choice == "rock" and computer_choice == "scissors") or \
             (user_choice == "scissors" and computer_choice == "paper") or \
             (user_choice == "paper" and computer_choice == "rock"):
            self.user_score += 1
            return "You win!"
        else:
            self.computer_score += 1
            return "You lose!"

    def play(self, user_choice):
        computer_choice = self.get_computer_choice()
        result = self.determine_winner(user_choice, computer_choice)
        
        self.result_label.config(text=f"You chose: {user_choice}, Computer chose: {computer_choice}\n{result}")
        self.score_label.config(text=f"Score: You {self.user_score} - Computer {self.computer_score}")

if __name__ == "__main__":
    root = tk.Tk()
    game = RockPaperScissors(root)
    root.mainloop()
